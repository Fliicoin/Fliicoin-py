def test():
  print('tested')